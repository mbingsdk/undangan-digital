
  # Desain Frontend UI/UX Modern

  This is a code bundle for Desain Frontend UI/UX Modern. The original project is available at https://www.figma.com/design/Yb0PWnZE5KTPF3lNNsc25g/Desain-Frontend-UI-UX-Modern.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  