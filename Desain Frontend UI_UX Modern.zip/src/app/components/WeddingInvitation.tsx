import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  MapPin,
  Clock,
  Heart,
  Gift,
  MessageSquare,
  Share2,
  ChevronDown,
  CheckCircle2,
  Image as ImageIcon,
  Disc,
  X,
  CreditCard,
  Copy,
  CalendarDays
} from "lucide-react";

export function WeddingInvitation() {
  const [isOpened, setIsOpened] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [musicPlaying, setMusicPlaying] = useState(false);
  const [rsvpStatus, setRsvpStatus] = useState<"Hadir" | "Tidak Hadir" | "Mungkin" | null>(null);
  const [guestCount, setGuestCount] = useState(1);
  const [guestName, setGuestName] = useState("");
  const [wishMessage, setWishMessage] = useState("");
  const [wishName, setWishName] = useState("");
  const [isRsvpSubmitted, setIsRsvpSubmitted] = useState(false);
  
  const [wishes, setWishes] = useState<Array<{ name: string; message: string }>>([
    { name: "Sarah & John", message: "Selamat menempuh hidup baru! Semoga menjadi keluarga yang sakinah, mawaddah, warahmah." },
    { name: "Michael Chen", message: "Doa terbaik untuk kalian berdua. Semoga cinta kalian terus tumbuh setiap harinya." },
  ]);

  const wedding = {
    groomName: "Alexander",
    brideName: "Isabella",
    groomFullName: "Alexander James Bennett",
    brideFullName: "Isabella Rose Martinez",
    tagline: "Dua hati, satu cinta, selamanya bersama",
    openingText: "Atas berkat rahmat Tuhan Yang Maha Esa dan dengan penuh rasa syukur, kami bermaksud mengundang Bapak/Ibu/Saudara/i untuk hadir pada acara pernikahan kami.",
    events: [
      {
        title: "Akad Nikah",
        date: "Sabtu, 14 Juni 2025",
        time: "08:00 - 10:00 WIB",
        venue: "Masjid Agung Al-Akbar",
        address: "Jl. Masjid Al-Akbar Timur No.1, Surabaya",
        mapsUrl: "https://maps.google.com",
      },
      {
        title: "Resepsi Pernikahan",
        date: "Sabtu, 14 Juni 2025",
        time: "19:00 - 22:00 WIB",
        venue: "The Grand Ballroom, Hotel Majapahit",
        address: "Jl. Tunjungan No.65, Surabaya",
        mapsUrl: "https://maps.google.com",
      },
    ],
    gallery: [
      "https://images.unsplash.com/photo-1615439935188-5e488fc6b764?q=80&w=1080",
      "https://images.unsplash.com/photo-1587271407850-8d438ca9fdf2?q=80&w=1080",
      "https://images.unsplash.com/photo-1723802205505-2f88b2227718?q=80&w=1080",
      "https://images.unsplash.com/photo-1596457221755-b96bc3a6df18?q=80&w=1080",
      "https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=1080",
      "https://images.unsplash.com/photo-1607357910286-1ff94ac13c24?q=80&w=1080",
    ],
    giftAccounts: [
      {
        provider: "Bank BCA",
        accountNumber: "1234567890",
        accountHolder: "Alexander James",
      },
      {
        provider: "Bank Mandiri",
        accountNumber: "0987654321",
        accountHolder: "Isabella Rose",
      },
    ],
    weddingDate: new Date("2025-06-14T08:00:00"),
    weddingDateFormatted: "14 . 06 . 2025"
  };

  const handleOpenInvitation = () => {
    setIsOpened(true);
    setMusicPlaying(true);
    window.scrollTo(0, 0);
  };

  const handleSubmitRSVP = (e: React.FormEvent) => {
    e.preventDefault();
    setIsRsvpSubmitted(true);
    setTimeout(() => {
      setGuestName("");
      setRsvpStatus(null);
      setGuestCount(1);
      setIsRsvpSubmitted(false);
    }, 3000);
  };

  const handleSubmitWish = (e: React.FormEvent) => {
    e.preventDefault();
    if (wishName && wishMessage) {
      setWishes([{ name: wishName, message: wishMessage }, ...wishes]);
      setWishName("");
      setWishMessage("");
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const shareWhatsApp = () => {
    const message = `Tanpa mengurangi rasa hormat, kami mengundang Anda untuk hadir di acara pernikahan kami:\n\n*${wedding.groomName} & ${wedding.brideName}*\n\nSilakan buka undangan digital kami melalui tautan berikut:\n${window.location.href}\n\nMerupakan suatu kehormatan dan kebahagiaan bagi kami apabila Anda berkenan hadir untuk memberikan doa restu.\n\nTerima kasih.`;
    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, "_blank");
  };

  const [timeLeft, setTimeLeft] = useState({ Hari: 0, Jam: 0, Menit: 0, Detik: 0 });

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date().getTime();
      const distance = wedding.weddingDate.getTime() - now;
      if (distance < 0) return;
      
      setTimeLeft({
        Hari: Math.floor(distance / (1000 * 60 * 60 * 24)),
        Jam: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        Menit: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
        Detik: Math.floor((distance % (1000 * 60)) / 1000),
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [wedding.weddingDate]);

  const fadeInUp = {
    hidden: { opacity: 0, y: 40 },
    visible: { opacity: 1, y: 0, transition: { duration: 1, ease: [0.16, 1, 0.3, 1] } }
  };
  
  const staggerContainer = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.2 } }
  };

  if (!isOpened) {
    return (
      <div className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#1a1a1a]">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat scale-105" 
          style={{ backgroundImage: `url('${wedding.gallery[0]}')` }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/80" />
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          className="relative z-10 text-center px-6 flex flex-col items-center justify-center h-full w-full"
        >
          <p className="text-zinc-300 tracking-[0.4em] uppercase text-xs md:text-sm mb-6">
            Undangan Pernikahan
          </p>
          <h1 className="text-6xl md:text-8xl lg:text-9xl font-serif text-white mb-4 drop-shadow-xl font-light">
            {wedding.groomName} <span className="font-script text-amber-200/80 mx-2 text-5xl md:text-7xl">&</span> {wedding.brideName}
          </h1>
          <p className="text-zinc-300 font-light mb-16 tracking-[0.3em] uppercase text-sm">
            {wedding.weddingDateFormatted}
          </p>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleOpenInvitation}
            className="group relative px-10 py-4 bg-transparent overflow-hidden border border-white/40 text-white transition-all hover:bg-white/10 backdrop-blur-sm"
          >
            <span className="relative z-10 flex items-center gap-3 text-xs tracking-[0.2em] uppercase">
              Buka Undangan
            </span>
          </motion.button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAFAFA] text-zinc-800 font-light selection:bg-amber-100 selection:text-amber-900">
      
      <button 
        onClick={() => setMusicPlaying(!musicPlaying)}
        className="fixed bottom-6 right-6 z-50 bg-white/90 backdrop-blur-md p-4 rounded-full shadow-xl border border-zinc-200/50 text-zinc-500 hover:text-amber-700 transition-all duration-500"
      >
        <Disc className={`w-5 h-5 ${musicPlaying ? 'animate-spin' : ''}`} style={{ animationDuration: '4s' }} />
      </button>

      {/* Hero Section */}
      <motion.section
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={staggerContainer}
        className="min-h-screen flex flex-col items-center justify-center px-4 py-20 relative"
      >
        <div className="absolute top-0 left-0 w-full h-full opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(#000 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
        
        <div className="text-center max-w-4xl relative z-10 flex flex-col items-center">
          <motion.p variants={fadeInUp} className="text-xs tracking-[0.4em] uppercase text-zinc-500 mb-10">
            Maha Suci Allah
          </motion.p>

          <motion.div variants={fadeInUp} className="flex flex-col items-center">
            <h2 className="text-5xl md:text-7xl font-serif text-zinc-800 leading-tight mb-4">
              {wedding.groomFullName}
            </h2>
            <div className="flex items-center justify-center my-6 gap-6">
              <div className="h-[1px] bg-zinc-300 w-16 md:w-32"></div>
              <span className="font-script text-amber-700 text-5xl">&</span>
              <div className="h-[1px] bg-zinc-300 w-16 md:w-32"></div>
            </div>
            <h2 className="text-5xl md:text-7xl font-serif text-zinc-800 leading-tight">
              {wedding.brideFullName}
            </h2>
          </motion.div>

          <motion.p variants={fadeInUp} className="text-zinc-600 text-sm md:text-base mt-16 max-w-2xl mx-auto leading-loose italic font-serif">
            "{wedding.openingText}"
          </motion.p>
        </div>
        
        <motion.div variants={fadeInUp} className="absolute bottom-10 animate-bounce text-zinc-400">
          <ChevronDown size={24} strokeWidth={1} />
        </motion.div>
      </motion.section>

      {/* Countdown Section */}
      <section className="py-24 px-4 bg-white">
        <motion.div 
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={staggerContainer}
          className="max-w-4xl mx-auto"
        >
          <motion.div variants={fadeInUp} className="text-center mb-16">
            <h3 className="font-script text-4xl text-amber-700 mb-2">Menuju Hari Bahagia</h3>
            <p className="text-xs tracking-[0.3em] uppercase text-zinc-500">{wedding.weddingDateFormatted}</p>
          </motion.div>

          <div className="flex justify-center items-center gap-4 md:gap-12">
            {Object.entries(timeLeft).map(([unit, value], i, arr) => (
              <motion.div key={unit} variants={fadeInUp} className="flex items-center gap-4 md:gap-12">
                <div className="text-center">
                  <div className="text-4xl md:text-6xl font-serif text-zinc-800 mb-3 font-light">
                    {value.toString().padStart(2, "0")}
                  </div>
                  <div className="text-[10px] md:text-xs uppercase tracking-[0.2em] text-zinc-400">
                    {unit}
                  </div>
                </div>
                {i !== arr.length - 1 && (
                  <div className="w-[1px] h-12 bg-zinc-200"></div>
                )}
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* Event Details */}
      <section className="py-24 px-4 bg-[#F9F9F7]">
        <div className="max-w-5xl mx-auto">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeInUp}
            className="text-center mb-16"
          >
            <h3 className="text-3xl font-serif text-zinc-800 mb-4">Rangkaian Acara</h3>
            <div className="h-[1px] w-12 bg-amber-700 mx-auto"></div>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-0 border-[0.5px] border-zinc-200 bg-white">
            {wedding.events.map((event, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 1, delay: index * 0.2 }}
                className={`p-10 md:p-16 flex flex-col items-center text-center ${index === 0 ? 'border-b md:border-b-0 md:border-r border-zinc-200' : ''}`}
              >
                <h4 className="text-2xl font-serif text-amber-800 mb-6">{event.title}</h4>
                
                <div className="space-y-6 flex flex-col items-center w-full">
                  <div className="flex flex-col items-center">
                    <CalendarDays className="text-zinc-300 mb-3" size={20} strokeWidth={1.5} />
                    <p className="font-medium text-zinc-800 uppercase text-xs tracking-widest">{event.date}</p>
                    <p className="text-zinc-500 text-sm mt-1">{event.time}</p>
                  </div>

                  <div className="w-12 h-[1px] bg-zinc-100"></div>

                  <div className="flex flex-col items-center">
                    <MapPin className="text-zinc-300 mb-3" size={20} strokeWidth={1.5} />
                    <p className="font-medium text-zinc-800">{event.venue}</p>
                    <p className="text-zinc-500 text-sm mt-1 mb-6 max-w-[200px] leading-relaxed">{event.address}</p>
                  </div>
                </div>

                <a
                  href={event.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-auto px-8 py-3 border border-zinc-300 text-[10px] uppercase tracking-[0.2em] text-zinc-600 hover:bg-zinc-50 hover:text-amber-800 transition-all duration-300"
                >
                  Lihat Peta
                </a>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-24 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeInUp}
            className="text-center mb-16"
          >
            <h3 className="text-3xl font-serif text-zinc-800 mb-4">Galeri Bahagia</h3>
            <div className="h-[1px] w-12 bg-amber-700 mx-auto"></div>
          </motion.div>

          <div className="columns-1 md:columns-2 lg:columns-3 gap-4 space-y-4">
            {wedding.gallery.map((image, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                className="relative overflow-hidden group cursor-pointer break-inside-avoid"
                onClick={() => setSelectedImage(image)}
              >
                <img
                  src={image}
                  alt={`Gallery ${index + 1}`}
                  className="w-full h-auto object-cover transition-transform duration-700 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-500 flex items-center justify-center">
                  <ImageIcon className="text-white opacity-0 group-hover:opacity-100 transition-opacity duration-500" size={28} strokeWidth={1} />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* RSVP Section */}
      <section className="py-24 px-4 bg-[#F9F9F7]">
        <div className="max-w-2xl mx-auto">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeInUp}
            className="text-center mb-16"
          >
            <h3 className="text-3xl font-serif text-zinc-800 mb-4">Konfirmasi Kehadiran</h3>
            <div className="h-[1px] w-12 bg-amber-700 mx-auto mb-6"></div>
            <p className="text-zinc-500 text-sm leading-relaxed max-w-md mx-auto">
              Merupakan suatu kehormatan bagi kami apabila Bapak/Ibu/Saudara/i berkenan hadir.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
            className="bg-white p-10 md:p-14 border-[0.5px] border-zinc-200"
          >
            {isRsvpSubmitted ? (
              <div className="text-center py-12">
                <CheckCircle2 className="mx-auto text-amber-600 mb-4" size={48} strokeWidth={1} />
                <h4 className="text-xl font-serif text-zinc-800 mb-2">Terima Kasih!</h4>
                <p className="text-zinc-500 text-sm">Konfirmasi kehadiran Anda telah kami terima.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmitRSVP}>
                <div className="mb-8">
                  <input
                    type="text"
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                    placeholder="Nama Lengkap"
                    className="w-full bg-transparent border-b border-zinc-300 py-3 px-0 focus:outline-none focus:border-amber-700 transition-colors text-zinc-800 placeholder-zinc-400"
                    required
                  />
                </div>

                <div className="mb-10">
                  <p className="text-sm text-zinc-500 mb-4">Apakah Anda akan hadir?</p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {["Hadir", "Tidak Hadir", "Mungkin"].map((option) => (
                      <button
                        key={option}
                        type="button"
                        onClick={() => setRsvpStatus(option as any)}
                        className={`py-3 px-4 text-xs tracking-widest uppercase transition-all duration-300 border ${
                          rsvpStatus === option
                            ? "border-amber-700 bg-amber-50 text-amber-900"
                            : "border-zinc-200 text-zinc-500 hover:border-zinc-300"
                        }`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                </div>

                {rsvpStatus === "Hadir" && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="mb-10 overflow-hidden"
                  >
                    <p className="text-sm text-zinc-500 mb-4">Jumlah Kehadiran (maks. 2)</p>
                    <select
                      value={guestCount}
                      onChange={(e) => setGuestCount(parseInt(e.target.value))}
                      className="w-full bg-transparent border-b border-zinc-300 py-3 px-0 focus:outline-none focus:border-amber-700 transition-colors text-zinc-800"
                    >
                      <option value="1">1 Orang</option>
                      <option value="2">2 Orang</option>
                    </select>
                  </motion.div>
                )}

                <button
                  type="submit"
                  disabled={!guestName || !rsvpStatus}
                  className="w-full bg-zinc-900 text-white py-4 text-xs tracking-[0.2em] uppercase hover:bg-amber-800 transition-colors duration-500 disabled:opacity-50 disabled:hover:bg-zinc-900"
                >
                  Kirim Konfirmasi
                </button>
              </form>
            )}
          </motion.div>
        </div>
      </section>

      {/* Gift Section */}
      <section className="py-24 px-4 bg-white">
        <div className="max-w-4xl mx-auto">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeInUp}
            className="text-center mb-16"
          >
            <h3 className="text-3xl font-serif text-zinc-800 mb-4">Tanda Kasih</h3>
            <div className="h-[1px] w-12 bg-amber-700 mx-auto mb-6"></div>
            <p className="text-zinc-500 text-sm leading-relaxed max-w-xl mx-auto">
              Doa restu Anda merupakan karunia yang sangat berarti bagi kami. Namun jika Anda ingin memberikan tanda kasih, Anda dapat mengirimkannya melalui:
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-6">
            {wedding.giftAccounts.map((account, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                className="bg-[#F9F9F7] p-10 border-[0.5px] border-zinc-200 text-center flex flex-col items-center"
              >
                <CreditCard className="text-zinc-300 mb-6" size={32} strokeWidth={1} />
                <p className="font-serif text-xl text-zinc-800 mb-1">{account.provider}</p>
                <p className="text-zinc-500 text-sm mb-8 uppercase tracking-widest">{account.accountHolder}</p>
                
                <p className="text-2xl font-light tracking-widest text-zinc-800 mb-8 font-mono">
                  {account.accountNumber}
                </p>

                <button
                  onClick={() => copyToClipboard(account.accountNumber)}
                  className="flex items-center gap-2 px-6 py-3 bg-white border border-zinc-200 text-[10px] uppercase tracking-[0.2em] text-zinc-600 hover:border-amber-700 hover:text-amber-800 transition-all duration-300"
                >
                  <Copy size={14} />
                  Salin Rekening
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Wishes Section */}
      <section className="py-24 px-4 bg-[#F9F9F7]">
        <div className="max-w-3xl mx-auto">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeInUp}
            className="text-center mb-16"
          >
            <h3 className="text-3xl font-serif text-zinc-800 mb-4">Ucapan & Doa</h3>
            <div className="h-[1px] w-12 bg-amber-700 mx-auto mb-6"></div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
            className="mb-16"
          >
            <form onSubmit={handleSubmitWish} className="bg-white p-8 md:p-12 border-[0.5px] border-zinc-200">
              <div className="mb-6">
                <input
                  type="text"
                  value={wishName}
                  onChange={(e) => setWishName(e.target.value)}
                  placeholder="Nama Anda"
                  className="w-full bg-transparent border-b border-zinc-300 py-3 px-0 focus:outline-none focus:border-amber-700 transition-colors text-zinc-800 placeholder-zinc-400"
                  required
                />
              </div>

              <div className="mb-8">
                <textarea
                  value={wishMessage}
                  onChange={(e) => setWishMessage(e.target.value)}
                  placeholder="Tulis ucapan dan doa Anda..."
                  rows={3}
                  className="w-full bg-transparent border-b border-zinc-300 py-3 px-0 focus:outline-none focus:border-amber-700 transition-colors text-zinc-800 placeholder-zinc-400 resize-none"
                  required
                />
              </div>

              <button
                type="submit"
                className="flex items-center justify-center gap-2 w-full md:w-auto px-8 py-3 bg-zinc-900 text-white text-[10px] uppercase tracking-[0.2em] hover:bg-amber-800 transition-colors duration-500"
              >
                <MessageSquare size={14} />
                Kirim Ucapan
              </button>
            </form>
          </motion.div>

          <div className="space-y-8 h-96 overflow-y-auto pr-4 scrollbar-thin scrollbar-thumb-zinc-200">
            <AnimatePresence>
              {wishes.map((wish, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="pl-6 border-l-[1px] border-amber-700/30"
                >
                  <p className="font-medium text-zinc-800 text-sm mb-2">{wish.name}</p>
                  <p className="text-zinc-500 text-sm leading-relaxed font-serif italic">"{wish.message}"</p>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* Closing Section */}
      <section className="py-32 px-4 bg-white">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeInUp}
          >
            <div className="font-script text-5xl text-amber-700 mb-8">Terima Kasih</div>
            
            <p className="text-zinc-500 text-sm md:text-base leading-loose max-w-xl mx-auto mb-16">
              Merupakan suatu kebahagiaan bagi kami apabila Bapak/Ibu/Saudara/i berkenan hadir dan memberikan doa restu.
            </p>

            <div className="mb-16">
              <p className="text-xs tracking-[0.3em] uppercase text-zinc-400 mb-4">Kami yang berbahagia</p>
              <h2 className="text-3xl md:text-5xl font-serif text-zinc-800">
                {wedding.groomName} <span className="font-script text-amber-700 mx-2">&</span> {wedding.brideName}
              </h2>
            </div>

            <button
              onClick={shareWhatsApp}
              className="group flex items-center gap-3 px-8 py-4 bg-[#25D366] text-white rounded-full mx-auto hover:bg-[#128C7E] transition-colors duration-300 shadow-lg shadow-[#25D366]/20"
            >
              <Share2 size={18} />
              <span className="text-xs uppercase tracking-widest font-medium">Bagikan via WhatsApp</span>
            </button>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-zinc-100 bg-white">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-zinc-400 text-[10px] uppercase tracking-[0.2em]">Dibuat dengan cinta</p>
        </div>
      </footer>

      {/* Image Modal */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={() => setSelectedImage(null)}
            className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center p-4 cursor-zoom-out"
          >
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute top-6 right-6 text-white/50 hover:text-white transition-colors"
            >
              <X size={32} strokeWidth={1} />
            </button>
            <motion.img
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
              src={selectedImage}
              alt="Gallery Preview"
              className="max-w-full max-h-full object-contain"
              onClick={(e) => e.stopPropagation()}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
